#include "ReShade.fxh"

/*
    NeuralForge for GShade — FFXIV prototype
    Project by Void, with ChatGPT-assisted development
    Version 0.2.0

    Screen-space post-processing only. Not a trained neural network.
    Does not identify body regions or change geometry/transparency.
*/

texture2D NF_BackBufferTex : COLOR;
sampler2D NF_BackBufferSampler { Texture = NF_BackBufferTex; };

uniform float NF_Detail < ui_type = "slider"; ui_label = "Fine Detail"; ui_min = 0.0; ui_max = 1.5; ui_step = 0.01; > = 0.30;
uniform float NF_EdgeClarity < ui_type = "slider"; ui_label = "Edge Clarity"; ui_min = 0.0; ui_max = 1.0; ui_step = 0.01; > = 0.20;
uniform float NF_LocalContrast < ui_type = "slider"; ui_label = "Local Contrast"; ui_min = 0.0; ui_max = 1.0; ui_step = 0.01; > = 0.15;
uniform float NF_SoftLighting < ui_type = "slider"; ui_label = "Soft Lighting"; ui_tooltip = "Global tonal lift only; does not isolate skin or character regions."; ui_min = 0.0; ui_max = 0.5; ui_step = 0.01; > = 0.05;
uniform float NF_FabricSheen < ui_type = "slider"; ui_label = "Fabric Sheen"; ui_tooltip = "Global highlight response; cannot isolate clothing materials."; ui_min = 0.0; ui_max = 0.5; ui_step = 0.01; > = 0.04;
uniform float NF_ColorRichness < ui_type = "slider"; ui_label = "Color Richness"; ui_min = 0.0; ui_max = 1.0; ui_step = 0.01; > = 0.08;
uniform float NF_Blend < ui_type = "slider"; ui_label = "Overall Blend"; ui_min = 0.0; ui_max = 1.0; ui_step = 0.01; > = 0.80;
uniform bool NF_ProtectHighlights < ui_label = "Protect Bright Highlights"; > = true;

texture2D NF_SourceTex { Width = BUFFER_WIDTH; Height = BUFFER_HEIGHT; Format = BUFFER_FORMAT; };
sampler2D NF_SourceSampler { Texture = NF_SourceTex; };

float NF_Luma(float3 c) { return dot(c, float3(0.2126, 0.7152, 0.0722)); }

float4 PS_Copy(float4 pos : SV_Position, float2 uv : TEXCOORD) : SV_Target
{
    return tex2D(NF_BackBufferSampler, uv);
}

float4 PS_NeuralForge(float4 pos : SV_Position, float2 uv : TEXCOORD) : SV_Target
{
    float2 px = BUFFER_PIXEL_SIZE;
    float3 c = tex2D(NF_SourceSampler, uv).rgb;
    float3 n = tex2D(NF_SourceSampler, uv + float2(0.0, -px.y)).rgb;
    float3 s = tex2D(NF_SourceSampler, uv + float2(0.0,  px.y)).rgb;
    float3 e = tex2D(NF_SourceSampler, uv + float2( px.x, 0.0)).rgb;
    float3 w = tex2D(NF_SourceSampler, uv + float2(-px.x, 0.0)).rgb;

    float l = NF_Luma(c);
    float wn = rcp(1.0 + abs(l - NF_Luma(n)) * 8.0);
    float ws = rcp(1.0 + abs(l - NF_Luma(s)) * 8.0);
    float we = rcp(1.0 + abs(l - NF_Luma(e)) * 8.0);
    float ww = rcp(1.0 + abs(l - NF_Luma(w)) * 8.0);
    float3 avg = (n * wn + s * ws + e * we + w * ww) / max(wn + ws + we + ww, 0.0001);

    float3 highpass = clamp(c - avg, -0.10, 0.10);
    float3 result = c + highpass * NF_Detail;
    float3 crossAvg = (n + s + e + w) * 0.25;
    float highlightGuard = NF_ProtectHighlights ? (1.0 - smoothstep(0.70, 1.0, l)) : 1.0;
    result += clamp(c - crossAvg, -0.08, 0.08) * NF_EdgeClarity * highlightGuard;
    result += highpass * NF_LocalContrast;

    // Global image-level appearance approximations; no material segmentation.
    result += NF_SoftLighting * (1.0 - smoothstep(0.25, 0.95, l)) * 0.08;
    float highlight = smoothstep(0.45, 0.90, l) * (1.0 - smoothstep(0.94, 1.0, l));
    result += highlight * NF_FabricSheen * 0.05;

    float lum = NF_Luma(result);
    result = lerp(lum.xxx, result, 1.0 + NF_ColorRichness * 0.18);
    result = saturate(result);
    return float4(lerp(c, result, NF_Blend), 1.0);
}

technique NeuralForge < ui_label = "NeuralForge — FFXIV Character Detail Prototype"; >
{
    pass
    {
        VertexShader = PostProcessVS;
        PixelShader = PS_Copy;
        RenderTarget = NF_SourceTex;
    }
    pass
    {
        VertexShader = PostProcessVS;
        PixelShader = PS_NeuralForge;
    }
}
