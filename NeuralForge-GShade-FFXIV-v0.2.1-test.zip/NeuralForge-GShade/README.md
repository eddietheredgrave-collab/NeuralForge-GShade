# NeuralForge for GShade — FFXIV Prototype

**Project by Void, with ChatGPT-assisted development**  
Version `0.2.0` · Early shader prototype

NeuralForge is an experimental GShade/ReShade FX post-processing project intended for Final Fantasy XIV. It offers restrained fine-detail enhancement, edge clarity, local contrast, and global lighting/material-appearance approximations.

## Current controls

- **Fine Detail:** restrained high-frequency detail enhancement.
- **Edge Clarity:** modest edge emphasis with highlight protection.
- **Local Contrast:** increases perceived definition.
- **Soft Lighting:** a small global tonal lift; it does not identify skin.
- **Fabric Sheen:** a global highlight response; it does not identify clothing.
- **Color Richness:** gentle saturation adjustment.
- **Overall Blend:** blends the effect with the original image.

## Honest limitations

This version is a conventional screen-space shader, **not a trained neural network or AI upscaler**. It processes the final image. It cannot reliably identify character-only pixels, distinguish skin from clothing, alter actual 3D proportions, reveal what is hidden under opaque clothing, or create real material transparency/subsurface scattering. The Soft Lighting and Fabric Sheen controls affect the overall image and are only approximations.

A future material-aware version would need reliable game-provided masks/material IDs or engine integration. No geometry warping is implemented.

## Install on Windows

1. Close FFXIV before copying files.
2. Find your GShade custom shader folder. Current GShade installations commonly use `%Public%\\GShade Custom Shaders\\Shaders\\`; some installations instead use the game's `gshade-shaders\\Shaders\\` folder. Check GShade's Settings tab for your active shader search paths.
3. Copy `Shaders/NeuralForge_GShade.fx` into the active `Shaders` folder.
4. Copy `Presets/NeuralForge_FFXIV_Starter.ini` into the preset folder selected by your installation. A common game-local folder is `gshade-presets`.
5. Launch FFXIV and open the GShade overlay (often `Home`, depending on your keybind). Reload shaders if needed, then enable **NeuralForge — FFXIV Character Detail Prototype** or load the starter preset.
6. Start with defaults. Increase settings gradually; excess sharpening can create halos, noise, and unstable-looking edges.

Do not overwrite built-in GShade files. Folder paths vary by version and installation. See the GShade project documentation for current install guidance: https://gshade.org/en/download and https://github.com/Mortalitas/GShade

## Test checklist

- Confirm the shader compiles without errors.
- Compare screenshots in the same location, camera angle, time/weather, and graphics settings.
- Check face edges, hair, foliage, UI text, dark scenes, and bright highlights.
- Record average and 1% low FPS before and after. No performance claim is made until measured.
- If the shader fails to compile, disable it and check the GShade log. This prototype has not been verified across every GShade build.

## Roadmap

1. Verify compilation in the exact GShade version used with FFXIV.
2. Capture matched before/after screenshots and measure GPU-time overhead.
3. Tune the default values for the FFXIV graphics update and different lighting conditions.
4. Investigate depth-aware processing only if the game's depth buffer is available and reliable.
5. Explore a separate research branch for ML reconstruction and true material-aware rendering.

## License

Original project files are licensed under MIT; see `LICENSE`.

## Credits

Project direction: **Void**  
Development assistance: **ChatGPT / OpenAI**  
Independent community project; not affiliated with or endorsed by Square Enix, GShade, or ReShade.
