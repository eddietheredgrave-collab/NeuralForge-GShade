# NeuralForge FFXIV test checklist

This is a prototype checklist, not a claim that the shader has already passed in-game testing.

## Static package checks
- [x] ZIP archive opens and lists project files.
- [x] Shader source, starter preset, README, and license are included.
- [x] Added an Evercold-inspired cinematic preset with restrained sharpening and highlight protection.
- [ ] Compile shader in the exact installed GShade version.
- [ ] Verify effect toggles on/off correctly in FFXIV.
- [ ] Capture identical screenshots with effect off/on in a bright outdoor scene, a dark interior, and a character close-up.
- [ ] Measure GPU frame-time impact at the same resolution and scene.
- [ ] Check for halos around hair, UI text sharpening, banding, and over-bright highlights.

## How to report a test
Record GPU model, game resolution, GShade version, graphics API, average frame time with effect off/on, and screenshots. Do not compare FPS from different scenes or camera positions.
